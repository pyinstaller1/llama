


"""
from transformers import MarianMTModel, MarianTokenizer
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message="Recommended: pip install sacremoses.")

path = "C:\\Users\\Administrator\\trans\\en-ja" # 다운로드 위치

model = MarianMTModel.from_pretrained(path)
tokenizer = MarianTokenizer.from_pretrained(path)

def translate(text):
    tokens = tokenizer(text, return_tensors="pt", padding=True)
    output = model.generate(**tokens)
    return tokenizer.decode(output[0], skip_special_tokens=True)

print(translate("What are you doing?"))
"""






"""

from transformers import MarianMTModel, MarianTokenizer

path = "C:\\Users\\Administrator\\trans\\opus-mt-ko-en"  # 다운로드 위치


tokenizer = MarianTokenizer.from_pretrained(path)
model = MarianMTModel.from_pretrained(path)

def translate(text):
    tokens = tokenizer(text, return_tensors="pt", padding=True)
    generated_ids = model.generate(**tokens)
    return tokenizer.decode(generated_ids[0], skip_special_tokens=True)

if __name__ == "__main__":
    korean_text = "AI가 뭐야?"
    english_text = translate(korean_text)
    print("번역:", english_text)
"""












'''

from transformers import MarianMTModel, MarianTokenizer

model_name_en_ja = "Helsinki-NLP/opus-tatoeba-en-ja"

tokenizer_en_ja = MarianTokenizer.from_pretrained(model_name_en_ja)
model_en_ja = MarianMTModel.from_pretrained(model_name_en_ja)

def translate_en_ja(text):
    tokens = tokenizer_en_ja(text, return_tensors="pt", padding=True)
    output = model_en_ja.generate(**tokens)
    return tokenizer_en_ja.decode(output[0], skip_special_tokens=True)

# 테스트
print(translate_en_ja("Hello, how are you?"))

'''




from transformers import MarianMTModel, MarianTokenizer

# 실제 저장된 모델 경로
# model_path = r"C:\Users\Administrator\.cache\huggingface\hub\models--Helsinki-NLP--opus-tatoeba-en-ja\snapshots\3a282648cb991174f3c423e376aff3a13e5edaaf"
model_path = "C:\\Users\\Administrator\\trans\\en-ja"  # 다운로드 위치


# 오프라인 로딩
tokenizer = MarianTokenizer.from_pretrained(model_path)
model = MarianMTModel.from_pretrained(model_path)

# 테스트 번역
def translate_en_to_ja(text):
    inputs = tokenizer(text, return_tensors="pt", padding=True)
    output = model.generate(**inputs)
    return tokenizer.decode(output[0], skip_special_tokens=True)

# 예시
print(translate_en_to_ja("This is a pen."))














