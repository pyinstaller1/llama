from PyQt5 import QtWidgets
from PyQt5.QtCore import QTimer

import kiril
from RUSSIA import *
from kiril import *
import pyperclip


class MyWindow(QtWidgets.QWidget):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("러시아어 단어")
        self.setGeometry(300, 200, 1025, 550)
        self.text = ""
        self.list = []
        self.i7 = 0
        self.i8 = 0


        button01 = QtWidgets.QPushButton(self)
        button02 = QtWidgets.QPushButton(self)

        button01.setStyleSheet("background-color: silver;font-size:21px;font-family:Times New Roman;")
        button01.clicked.connect(self.btn_clicked01)
        button01.setText(' 단어 => ')
        button01.move(397, 512)

        button02.setStyleSheet("background-color: silver;font-size:21px;font-family:Times New Roman;")
        button02.clicked.connect(self.btn_clicked02)
        button02.setText('파일 데이터')
        button02.move(893, 512)

        self.input01 = QtWidgets.QLineEdit(self)
        self.input01.setText("russia.txt")
        self.input01.setGeometry(783, 512, 107, 35)

        self.textarea01 = QtWidgets.QTextEdit(self)
        self.textarea01.setText("Найдите слова россия\nс ударением и значением")
        self.textarea01.setGeometry(10, 10, 500, 500)

        self.textarea02 = QtWidgets.QTextEdit(self)
        self.textarea02.setText("")
        self.textarea02.setGeometry(517, 10, 500, 500)

        self.show()

    def btn_clicked01(self):
        self.textarea02.clear()
        self.list = input_Text(self.textarea01.toPlainText())
        print(self.list)
        self.i7 = 0
        self.text = ""
        self.textarea02.setText("888")
        print(7)

        timer = QTimer(self)
        timer.timeout.connect(self.showNumber)
        if self.i8 == 0:
            self.i8 = 1
            timer.start(100)
            print(self.text)

    def btn_clicked02(self):
        self.textarea02.clear()
        a1 = self.input01.text()
        print(a1)
        file = open(a1, "r", encoding="UTF8")
        self.list = input_Text(file.read())
        self.i7 = 0
        self.text = ""

        timer = QTimer(self)
        timer.timeout.connect(self.showNumber)
        if self.i8 == 0:
            self.i8 = 1
            timer.start(100)

    def showNumber(self):
        print(88888888888)
        print(self.i7)
        print(self.list)
        if self.i7 < len(self.list):
            list_original, list_korean, list_meaning = get_Original_Word(self.list[self.i7])
            print(list_original)
            print(777)
            if list_original != "":
                self.text += list_original + " [" + list_korean + "] " + list_meaning + "\n"
                pyperclip.copy(self.text)
                self.textarea02.setText(str(self.text))
                self.file_write = open("write.txt", "w", encoding="UTF8")
                self.file_write.write(str(self.text))
                self.file_write.close()
            self.i7 += 1
        elif self.i7 >= len(self.list):
            pass
        print(self.text)
        print(self.list)
        print(8)


    def endTimer(self):
        self.timer.stop()






if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    win = MyWindow()
    app.exec_()
