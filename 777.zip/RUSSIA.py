import bs4
import requests
import pyperclip
from kiril import *
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

st = " глу́пый хвата́ет сегодня "

st7 = """
Нет, я сегодня дома
Продолжается
Тебе надо найти кого-то там на месте. Ты умный парень.
Тогда иди к своей мечте
Едь в инчхон
В Москву самолёты летают, там аэропорты открыты
В белгороде аэропорт закрыт
Пока не как
У меня нет ремонта же и мебели
Ты студию для записи песен снял?
Нет, рядом
Наверное
Аэропорт закрыт
И война не заканчивается
Ну вот тогда и нужно говорить
Что за глупости
Распутин злой убийца
Нам хватает войны
Я только что пришла на работу
Сейчас буду пить чай с мяты
Замерзла
А у нас туман
Я еду на работу
Я только пришла на работу
Привет


"""








'''
list = input_Text(st)
list_original, list_korean, list_meaning = get_Original(list)
get_Meaning(list_original, list_korean, list_meaning)

'''
